<?php
/*
Plugin Name: Odoo Form Handler
Description: Plugin personnalisé pour envoyer des données de Forminator vers l'API Odoo.
Version: 1.0
Author: Esk
*/

// Ajouter une Page d'Administration
add_action('admin_menu', 'odoo_form_handler_menu');

function odoo_form_handler_menu() {
    add_menu_page(
        'Paramètres Odoo',
        'Paramètres Odoo',
        'manage_options',
        'odoo-form-handler-settings',
        'odoo_form_handler_settings_page'
    );
}

// Ajouter des Champs de Configuration
add_action('admin_init', 'odoo_form_handler_settings');

function odoo_form_handler_settings() {
    register_setting('odoo-form-handler-settings', 'selected_form');
    register_setting('odoo-form-handler-settings', 'odoo_access_token');
    register_setting('odoo-form-handler-settings', 'odoo_api_url');
    register_setting('odoo-form-handler-settings', 'odoo_models');
    register_setting('odoo-form-handler-settings', 'Mapping_odoo_forminator');

    add_settings_section(
        'odoo-form-handler-section',
        'Configuration Odoo',
        'odoo_form_handler_section_callback',
        'odoo-form-handler-settings'
    );

    add_settings_field(
        'selected_form',
        'Sélectionnez le formulaire',
        'display_form_selector',
        'odoo-form-handler-settings',
        'odoo-form-handler-section'
    );

    $selected_form = get_option('selected_form');
    if (!empty($selected_form)) {
        display_form_settings($selected_form);
    }
}

function display_form_selector() {
    $forms = Forminator_API::get_forms();
    $selected_form = get_option('selected_form');
    ?>
    <div style="display: flex; align-items: center;">
        <form method="post" action="options.php">
            <?php settings_fields('odoo-form-handler-settings'); ?>
            <select name="selected_form" style="margin-right: 10px; height: 30px; font-size: 14px;width:35%;">
                <?php
                foreach ($forms as $form) {
                    $form_id = $form->id;
                    $form_name = $form->name;
                    $selected = selected($selected_form, $form_id, false);
                    echo '<option value="' . esc_attr($form_id) . '" ' . $selected . '>' . esc_html($form_name) . '</option>';
                }
                ?>
            </select>
            <?php submit_button('Afficher le formulaire', 'primary', 'submit_display_button', false); ?>
        </form>
    </div>
    <?php
}

function display_form_settings($selected_form_id) {

    $form = Forminator_API::get_form($selected_form_id);
    if ($form) {
        $form_id = $form->id;
        $form_name = $form->name;

        add_settings_field(
            'formulaire' . $form_id,
            'Nom du Formulaire',
            function () use ($form_id, $form_name) {
                echo '<h1>' . esc_html($form_name) . ' </h1>';
            },
            'odoo-form-handler-settings',
            'odoo-form-handler-section'
        );

        add_settings_field(
            'odoo_api_url_' . $form_id,
            'URL de l\'API Odoo ',
            function () use ($form_id) {
                echo '<input type="text" name="odoo_api_url_' . $form_id . '" value="' . esc_attr(get_post_meta($form_id, 'odoo_api_url', true)) . '" />';
            },
            'odoo-form-handler-settings',
            'odoo-form-handler-section'
        );

        add_settings_field(
            'odoo_access_token_' . $form_id,
            'Access Token Odoo',
            function () use ($form_id) {
                echo '<input type="text" name="odoo_access_token_' . $form_id . '" value="' . esc_attr(get_post_meta($form_id, 'odoo_access_token', true)) . '" />';
            },
            'odoo-form-handler-settings',
            'odoo-form-handler-section'
        );

        add_settings_field(
            'odoo_models_' . $form_id,
            'Models Odoo',
            function () use ($form_id) {
                echo '<input type="text" name="odoo_models_' . $form_id . '" value="' . esc_attr(get_post_meta($form_id, 'odoo_models', true)) . '" />';
                submit_button('Enregistrer les paramètres', 'primary', 'submit_save_button', false);
            },
            'odoo-form-handler-settings',
            'odoo-form-handler-section'
        );

        /*$forminator_fields_options = get_field_names_from_forminator($form_id);

        add_settings_field(
            'Mapping_odoo_forminator_' . $form_id,
            'Mappage ',
            function () use ($form_id, $forminator_fields_options) {
                display_field_mapping($form_id, $forminator_fields_options);
            },
            'odoo-form-handler-settings',
            'odoo-form-handler-section'
        );*/
    }
}

function get_field_names_from_odoo($form_id) {
    $odoo_api_url = get_post_meta($form_id, 'odoo_api_url', true);
    $odoo_models = get_post_meta($form_id, 'odoo_models', true);
    $odoo_access_token = get_post_meta($form_id, 'odoo_access_token', true);
    $full_odoo_api_url = rtrim($odoo_api_url, '/') . '/' . ltrim($odoo_models, '/');

    $response = wp_remote_get(
        $full_odoo_api_url,
        array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Access-Token' => $odoo_access_token,
            ),
        )
    );

    $field_names = array();

    if (!is_wp_error($response)) {
        $jsonString = wp_remote_retrieve_body($response);
        $data = json_decode($jsonString, true);

        if (isset($data['results'][0])) {
            $field_names = array_keys($data['results'][0]);
        }
    }

    return $field_names;
}

function get_field_names_from_forminator($form_id) {
    // Récupérer l'instance du formulaire
    $form = Forminator_API::get_form($form_id);

    // Vérifier si le formulaire existe
    if (!$form) {
        return array();
    }

    // Récupérer les champs du formulaire
    $fields = $form->get_fields();

    // Vérifier si des champs ont été récupérés
    if (empty($fields)) {
        return array();
    }

    $forminator_fields_options = array();

    foreach ($fields as $field) {
        // Vérifier si le champ a un slug valide
        if (isset($field->slug) && !empty($field->slug)) {
            // Utiliser le slug du champ comme clé
            $forminator_fields_options[$field->slug] = $field->slug;
        }
    }

    return $forminator_fields_options;
}


function display_field_mapping($form_id, $forminator_fields_options) {
    echo '<h2>Mapping entre les champs Odoo et Forminator</h2>';
    echo '<table class="form-table">';
    echo '<tr>';
    echo '<th>Champ Forminator</th>';
    echo '<th>Champ Odoo</th>';
    echo '<th>Sélectionner</th>'; // Ajouter une nouvelle colonne pour les cases à cocher

    $forminator_field_names = get_field_names_from_forminator($form_id);
    $odoo_field_names = get_field_names_from_odoo($form_id);

    foreach ($forminator_field_names as $forminator_field) {
        echo '<tr>';
        echo '<td>';
        generate_dropdown_menu('forminator', $form_id, $forminator_field, $forminator_field_names);
        echo '</td>';
        echo '<td>';
        generate_dropdown_menu('odoo', $form_id, $forminator_field, $odoo_field_names);
        echo '</td>';
        echo '<td>';
        generate_checkbox($form_id, $forminator_field);
        echo '</td>';
        echo '</tr>';
    }

    echo '</table>';
}

function generate_dropdown_menu($type, $form_id, $field, $options) {
    echo '<select name="' . $type . '_selected_field_' . $form_id . '[' . esc_attr($field) . ']" style="width:100%">';
    
    foreach ($options as $value) {
        $selected = selected($field, $value, false);
        echo '<option value="' . esc_attr($value) . '" ' . $selected . '>' . esc_html($value) . '</option>';
    }

    echo '</select>';
}

function generate_checkbox($form_id, $odoo_field) {
    $checkbox_name = 'selected_fields[' . $form_id . '][' . esc_attr($odoo_field) . ']';
    $checked = isset($_POST['selected_fields'][$form_id][$odoo_field]) && $_POST['selected_fields'][$form_id][$odoo_field] == 1 ? 'checked' : '';

    echo '<input type="checkbox" name="' . $checkbox_name . '" value="1" ' . $checked . '>';
}

function odoo_form_handler_section_callback() {
    // Optionnel : Ajoutez un texte descriptif ici
}

// Page d'administration des paramètres Odoo
function odoo_form_handler_settings_page() {
    ?>
    <div class="wrap">
        <h1>Paramètres Odoo</h1>

        <form method="post" action="">
            <?php
            settings_fields('odoo-form-handler-settings');
            do_settings_sections('odoo-form-handler-settings');

            // Vérifier si le formulaire a été soumis
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Vérifier si l'action est "submit_save_button"
                if (isset($_POST['submit_save_button'])) {
                    // Enregistrer les paramètres
                    save_forminator_odoo_form_settings();

                    // Vérifier si l'URL, le token et les modèles sont enregistrés
                    $selected_form = get_option('selected_form');
                    $odoo_api_url = get_post_meta($selected_form, 'odoo_api_url', true);
                    $odoo_access_token = get_post_meta($selected_form, 'odoo_access_token', true);
                    $odoo_models = get_post_meta($selected_form, 'odoo_models', true);

                    if (!empty($odoo_api_url) && !empty($odoo_access_token) && !empty($odoo_models)) {
                        // Afficher les champs à mapper
                        display_field_mapping($selected_form, get_field_names_from_forminator($selected_form));
                        submit_button('Enregistrer les paramètres', 'primary', 'submit_save_button', false);
                    } else {
                        // Afficher un message indiquant de saisir l'URL, le token et les modèles
                        echo '<p style="color: red;">Veuillez saisir l\'URL, le token et les modèles avant de mapper les champs.</p>';
                    }
                }
            }
            ?>
        </form>

        <?php
        // Output the saved values for debugging
        $forms = Forminator_API::get_forms();
        foreach ($forms as $form) {
            $form_id = $form->id;
            $odoo_api_url = get_post_meta($form_id, 'odoo_api_url', true);
            $odoo_access_token = get_post_meta($form_id, 'odoo_access_token', true);
            $odoo_models = get_post_meta($form_id, 'odoo_models', true);
            $forminator_field_names = get_post_meta($form_id, 'selected_fields', true);
            $odoo_selected_field = get_post_meta($form_id, 'odoo_selected_field_' . $form_id, true);

            echo "<h2>Form ID: $form_id</h2>";
            echo "<p>odoo_api_url: $odoo_api_url</p>";
            echo "<p>odoo_access_token: $odoo_access_token</p>";
            echo "<p>odoo_models: $odoo_models</p>";

            echo "<p>odoo_selected_field: " . print_r($odoo_selected_field, true) . "</p>";
        }
        ?>
    </div>
    <?php
}


// Enregistrez les paramètres spécifiques au formulaire lors de la sauvegarde des paramètres généraux
add_action('admin_init', 'save_forminator_odoo_form_settings');

function save_forminator_odoo_form_settings() {
    // Check if the form for displaying was submitted
    if (isset($_POST['submit_display_button'])) {
        $selected_form = get_option('selected_form');
        display_form_settings($selected_form);
        return; // Stop further processing
    }

    // Check if the form for saving settings was submitted
    if (isset($_POST['submit_save_button'])) {
        // Loop through each submitted field
        foreach ($_POST as $key => $value) {
            $form_id = null;
            $field_name = '';

            // Determine the form ID and field name based on the field prefix
            if (strpos($key, 'odoo_api_url_') === 0) {
                $form_id = str_replace('odoo_api_url_', '', $key);
                $field_name = 'odoo_api_url';
            } elseif (strpos($key, 'odoo_access_token_') === 0) {
                $form_id = str_replace('odoo_access_token_', '', $key);
                $field_name = 'odoo_access_token';
            } elseif (strpos($key, 'odoo_models_') === 0) {
                $form_id = str_replace('odoo_models_', '', $key);
                $field_name = 'odoo_models';
            } elseif (strpos($key, 'odoo_selected_field_') === 0) {
                $form_id = str_replace('odoo_selected_field_', '', $key);
                $field_name = 'odoo_selected_field_';
            }

            // If a valid form ID and field name are found, proceed with saving data
            if ($form_id !== null && $field_name !== '') {
                // Sanitize the value
                $value = sanitize_text_field($value);

                // Save the data in the form metadata
                update_post_meta($form_id, $field_name, $value);

                // Save selected field for the specific form
                $selected_value = isset($_POST['odoo_selected_field_' . $form_id]) ? $_POST['odoo_selected_field_' . $form_id] : array();
                $selected_value_checkbox = isset($_POST['selected_fields'][$form_id]) ? $_POST['selected_fields'][$form_id] : array();

                // Intersection of selected values from dropdown and checkboxes
                $result = array_intersect_key($selected_value, $selected_value_checkbox);
                $invertedArray = array_flip($result);

                // Update metadata with the selected fields
                update_post_meta($form_id, 'odoo_selected_field_' . $form_id, $invertedArray);

                // Debugging: Output data to error log
                error_log("Form ID: $form_id | Field Name: $field_name | Value: $value");
                error_log("Selected Field for Form ID $form_id: " . print_r($invertedArray, true));
            }
        }
    }
}

// Function to prepare data for Odoo API
function prepare_data_for_odoo($form_id, $entry) {
    $odoo_selected_fields = get_post_meta($form_id, 'odoo_selected_field_' . $form_id, true);

    $odoo_api_url = get_post_meta($form_id, 'odoo_api_url', true);
    $odoo_models = get_post_meta($form_id, 'odoo_models', true);
    $odoo_access_token = get_post_meta($form_id, 'odoo_access_token', true);

    $full_odoo_api_url = rtrim($odoo_api_url, '/') . '/' . ltrim($odoo_models, '/');

    $data_odoo = array();
    foreach ($odoo_selected_fields as $odoo_field => $forminator_field) {
        $field_value = isset($entry->meta_data[$forminator_field]['value']) ? $entry->meta_data[$forminator_field]['value'] : '';
        error_log(ucfirst($odoo_field) . ' : ' . $field_value);

        error_log("Mapping: $odoo_field => $forminator_field");

        $data_odoo[$odoo_field] = $field_value;
    }

    return array(
        'api_url' => $full_odoo_api_url,
        'access_token' => $odoo_access_token,
        'data' => $data_odoo,
    );
}

// Modified action hook
add_action('forminator_form_after_save_entry', 'send_data_to_odoo', 10, 2);

function send_data_to_odoo($form_id) {
    $entry = Forminator_Form_Entry_Model::get_latest_entry_by_form_id($form_id);

    if ($entry && isset($entry->meta_data)) {
        $odoo_data = prepare_data_for_odoo($form_id, $entry);

        $response = wp_remote_post(
            $odoo_data['api_url'],
            array(
                'method' => 'POST',
                'body' => json_encode($odoo_data['data']),
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Access-Token' => $odoo_data['access_token'],
                ),
            )
        );

        if (is_wp_error($response)) {
            error_log('Erreur lors de l\'envoi des données à Odoo : ' . $response->get_error_message());
        } else {
            $body = wp_remote_retrieve_body($response);
            error_log('Réponse d\'Odoo : ' . $body);
        }
    }
}