from odoo import api, fields, models
from datetime import datetime, timedelta
import logging

_logger = logging.getLogger(__name__)

class HrLeaveAllocationExtended(models.Model):
    _inherit = 'hr.leave.allocation'

    duration_allocated = fields.Float(string='Duration Allocated')

class PlanningSlot(models.Model):
    _inherit = 'planning.slot'

    @api.model
    def create_leave_allocation(self):
        # Retrieve employees with allocated hours in planning
        allocated_employee_ids = self.env['planning.slot'].search([('allocated_hours', '>', 0)]).mapped('employee_id.id')
        _logger.info("allocated_employee_ids")
        _logger.info(allocated_employee_ids)
        employees = self.env['hr.employee'].search([('id', 'in', allocated_employee_ids)])
        _logger.info("employees")
        _logger.info(employees)

        today = datetime.now()
        start_of_week = today - timedelta(days=(today.isoweekday()))
        end_of_week = start_of_week + timedelta(days=6)
        _logger.info("Today's Date:")
        _logger.info(today)
        _logger.info("Start of Week:")
        _logger.info(start_of_week)
        _logger.info("End of Week:")
        _logger.info(end_of_week)

        for employee in employees:
            # Retrieve allocated hours for an employee
            planning_slots = self.env['planning.slot'].search([
                ('employee_id', '=', employee.id),
                ('start_datetime', '>=', start_of_week),
                ('end_datetime', '<=', end_of_week),
                ('allocated_hours', '>', 0),
            ])

            _logger.info("planning_slots")
            _logger.info(planning_slots)
            _logger.info(planning_slots.mapped('allocated_hours'))
            total_allocated_hours = sum(planning_slots.mapped('allocated_hours'))
            _logger.info("total_allocated_hours")
            _logger.info(total_allocated_hours)

            # Calculate surplus or deficit hours
            difference_hours = total_allocated_hours - 40
            _logger.info("difference_hours")
            _logger.info(difference_hours)

            # Check if the total allocated hours are greater than 40
            if difference_hours != 0:
                leave_allocation_vals = {
                    'name': 'Allocation de congés pour heures supplémentaires',
                    'holiday_status_id': 34,
                    'allocation_type': 'accrual',
                    'duration_allocated': difference_hours,
                    'holiday_type': 'employee',
                    'employee_id': employee.id,
                }

                # Log the leave allocation details before creating it
                _logger.info(f"Creating leave allocation with values: {leave_allocation_vals}")

                # Create the leave allocation
                leave_allocation = self.env['hr.leave.allocation'].create(leave_allocation_vals)

                # Log the leave allocation details after creation
                _logger.info(f"Leave allocation created with ID: {leave_allocation.id}")