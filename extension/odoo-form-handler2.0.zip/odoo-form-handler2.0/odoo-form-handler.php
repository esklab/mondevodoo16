<?php
/*
Plugin Name: Odoo Form Handler
Description: Plugin personnalisé pour envoyer des données de Forminator vers l'API Odoo.
Version: 1.0
Author: Esk
*/

// Ajouter une Page d'Administration
add_action('admin_menu', 'odoo_form_handler_menu');

function odoo_form_handler_menu() {
    add_menu_page(
        'Paramètres Odoo',
        'Paramètres Odoo',
        'manage_options',
        'odoo-form-handler-settings',
        'odoo_form_handler_settings_page'
    );
}

// Ajouter des Champs de Configuration
add_action('admin_init', 'odoo_form_handler_settings');

function odoo_form_handler_settings() {
    register_setting('odoo-form-handler-settings', 'odoo_access_token');
    register_setting('odoo-form-handler-settings', 'odoo_api_url');
    register_setting('odoo-form-handler-settings', 'odoo_models');
    register_setting('odoo-form-handler-settings', 'forminator_field_names');

    add_settings_section(
        'odoo-form-handler-section',
        'Configuration Odoo',
        'odoo_form_handler_section_callback',
        'odoo-form-handler-settings'
    );

    $forms = Forminator_API::get_forms();
    foreach ($forms as $form) {
        $form_id = $form->id;
        $form_name=$form->name;

        add_settings_field(
            'odoo_api_url_' . $form_id,
            'URL de l\'API Odoo (Form ' . $form_name . ')',
            function () use ($form_id) {
                echo '<input type="text" name="odoo_api_url_' . $form_id . '" value="' . esc_attr(get_post_meta($form_id, 'odoo_api_url', true)) . '" />';
            },
            'odoo-form-handler-settings',
            'odoo-form-handler-section'
        );

        add_settings_field(
            'odoo_access_token_' . $form_id,
            'Access Token Odoo',
            function () use ($form_id) {
                echo '<input type="text" name="odoo_access_token_' . $form_id . '" value="' . esc_attr(get_post_meta($form_id, 'odoo_access_token', true)) . '" />';
            },
            'odoo-form-handler-settings',
            'odoo-form-handler-section'
        );

        add_settings_field(
            'odoo_models_' . $form_id,
            'Models Odoo',
            function () use ($form_id) {
                echo '<input type="text" name="odoo_models_' . $form_id . '" value="' . esc_attr(get_post_meta($form_id, 'odoo_models', true)) . '" />';
            },
            'odoo-form-handler-settings',
            'odoo-form-handler-section'
        );

        add_settings_field(
            'forminator_field_names_' . $form_id,
            'Noms des Champs Forminator (JSON) ',
            function () use ($form_id) {
                echo '<textarea name="forminator_field_names_'. $form_id .'" rows="8" style="width:80%">' . esc_textarea(get_post_meta($form_id, 'forminator_field_names', true)) . '</textarea>';
            },
            'odoo-form-handler-settings',
            'odoo-form-handler-section'
        );
    }
}

function odoo_form_handler_section_callback() {
    // Optionnel : Ajoutez un texte descriptif ici
}

function odoo_form_handler_settings_page() {
    // Affichez ici le contenu de la page d'administration
    ?>
    <div class="wrap">
        <h1>Paramètres Odoo </h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('odoo-form-handler-settings');
            do_settings_sections('odoo-form-handler-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Enregistrez les paramètres spécifiques au formulaire lors de la sauvegarde des paramètres généraux
add_action('admin_init', 'save_forminator_odoo_form_settings');

function save_forminator_odoo_form_settings() {
    // Enregistrez les paramètres spécifiques au formulaire pour chaque formulaire
    foreach ($_POST as $key => $value) {
        $form_id = null;

        // Vérifiez le préfixe pour déterminer s'il s'agit d'un champ de formulaire
        if (strpos($key, 'odoo_api_url_') === 0) {
            $form_id = str_replace('odoo_api_url_', '', $key);
            $field_name = 'odoo_api_url';
        } elseif (strpos($key, 'odoo_access_token_') === 0) {
            $form_id = str_replace('odoo_access_token_', '', $key);
            $field_name = 'odoo_access_token';
        } elseif (strpos($key, 'odoo_models_') === 0) {
            $form_id = str_replace('odoo_models_', '', $key);
            $field_name = 'odoo_models';
        } elseif (strpos($key, 'forminator_field_names_') === 0) {
            $form_id = str_replace('forminator_field_names_', '', $key);
            $field_name = 'forminator_field_names';
        }

        // Si un formulaire est trouvé, enregistrez les données
        if ($form_id !== null) {
            // Validation des données d'entrée
            $value = sanitize_text_field($value);

            // Enregistrez les données dans les métadonnées du formulaire
            update_post_meta($form_id, $field_name, $value);
        }
    }
}

// Action lors de la soumission d'un formulaire Forminator
add_action('forminator_form_after_save_entry', 'envoyer_donnees_odoo', 10, 2);

function envoyer_donnees_odoo($form_id) {
    // Récupérer la dernière entrée du formulaire
    $entry = Forminator_Form_Entry_Model::get_latest_entry_by_form_id($form_id);

    // Vérifier si l'entrée existe et si elle a des métadonnées
    if ($entry && isset($entry->meta_data)) {
        // Récupérer les valeurs spécifiques
        $forminator_field_names_json = get_post_meta($form_id,'forminator_field_names',true);
        $forminator_field_names = json_decode($forminator_field_names_json, true);

        // Récupérer les paramètres Odoo depuis les options de l'interface d'administration
        $odoo_api_url = get_post_meta($form_id, 'odoo_api_url', true);
        $odoo_models = get_post_meta($form_id,'odoo_models',true);
        $odoo_access_token = get_post_meta($form_id,'odoo_access_token',true);

        // Concaténer le modèle à l'URL de l'API
        $full_odoo_api_url = rtrim($odoo_api_url, '/') . '/' . ltrim($odoo_models, '/');


        // Construire les données à envoyer en utilisant les noms des champs Forminator
        $data_odoo = array();
        foreach ($forminator_field_names as $odoo_field => $forminator_field) {
            $field_value = isset($entry->meta_data[$forminator_field]['value']) ? $entry->meta_data[$forminator_field]['value'] : '';
            error_log(ucfirst($odoo_field) . ' : ' . $field_value);

            // Vous pouvez également imprimer le mapping dans les logs si nécessaire
            error_log("Mapping: $odoo_field => $forminator_field");

            // Ajouter la paire clé-valeur au tableau de données à envoyer à l'API Odoo
            $data_odoo[$odoo_field] = $field_value;
        }

        // Envoyer les données à l'API Odoo
        $response = wp_remote_post(
            $full_odoo_api_url,
            array(
                'method'  => 'POST',
                'body'    => json_encode($data_odoo),
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Access-Token'  => $odoo_access_token,
                ),
            )
        );

        // Vérifier la réponse
        if (is_wp_error($response)) {
            error_log('Erreur lors de l\'envoi des données à Odoo : ' . $response->get_error_message());
        } else {
            // Les données ont été envoyées avec succès
            // Vous pouvez traiter la réponse ici si nécessaire
            $body = wp_remote_retrieve_body($response);
            error_log('Réponse d\'Odoo : ' . $body);
        }
    }
}